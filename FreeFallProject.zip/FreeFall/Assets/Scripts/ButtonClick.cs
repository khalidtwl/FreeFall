﻿using UnityEngine;
using System.Collections;

public class ButtonClick : MonoBehaviour 
{
	// Loads Game
	public void LoadGame()
	{
		Application.LoadLevel ("GameScene");
	}
}
